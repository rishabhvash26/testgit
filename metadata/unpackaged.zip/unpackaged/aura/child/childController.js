({
	handle : function(component, event, helper) {
		alert("in child");
	}
})