({
	doInit : function(component, event, helper) {
		component.set("v.attr1",'rishabh');
	}
})